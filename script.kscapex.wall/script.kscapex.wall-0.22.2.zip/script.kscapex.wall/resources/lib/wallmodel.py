"""Wall layout: grid placement, related arrangement, camera and flight geometry (pure Python)."""
import math

from . import geometry as G


def grid_rows(count, layout=G.POSTER):
    """Rows for a library of `count` items: a wall roughly three times wider than tall.

    At least the layout's min_rows, so the wall fills the screen top to bottom - except for a
    handful of items (e.g. a few favourites), which sit in a short centred block instead of a
    single column."""
    if count <= 0:
        return layout.min_rows
    rows = int(round(math.sqrt(count / 3.0)))
    if count < layout.min_rows * 3:
        return max(1, rows)
    return max(layout.min_rows, min(G.WALL_MAX_ROWS, rows))



# KScapeX: the wall's order (C menu > View Options > Sort by), remembered per media kind.
SORTS = ('title', 'released', 'added')


def release_key(item):
    """Release date for sorting: the full date when Kodi has it, else the year ('' if neither)."""
    premiered = getattr(item, 'premiered', '') or ''
    year = getattr(item, 'year', 0) or 0
    return premiered or (f'{year:04d}' if year else '')


def sort_items(items, order):
    """`items` (in library order: by title) in the wall's order. 'title' keeps them; 'released'
    and 'added' put the newest first, items without a date last, ties in title order."""
    if order == 'released':
        return sorted(items, key=release_key, reverse=True)
    if order == 'added':
        return sorted(items, key=lambda m: getattr(m, 'dateadded', '') or '', reverse=True)
    return list(items)


class Wall:
    """Items (movies, albums, shows) placed on a rows x cols grid, addressed (col, row). Items are
    told apart by their `key`."""

    def __init__(self, rows, cols, cells, layout=G.POSTER):
        self.rows = rows
        self.cols = cols
        self.cells = cells                       # list indexed by col * rows + row; item or None
        self.layout = layout
        self.index = {m.key: i for i, m in enumerate(cells) if m is not None}

    @classmethod
    def row_major(cls, movies, rows=None, layout=G.POSTER):
        """KScapeX's wall: items in the given order left to right along a row, then the next row
        down (A to Z reads like a page). grid_rows always leaves the last row the only partial one."""
        rows = rows or grid_rows(len(movies), layout)
        cols = max(1, math.ceil(len(movies) / rows))
        cells = [None] * (rows * cols)
        for i, m in enumerate(movies):
            cells[(i % cols) * rows + i // cols] = m
        return cls(rows, cols, cells, layout)

    @classmethod
    def column_major(cls, movies, rows=None, layout=G.POSTER):
        """Initial wall: items in the given order, filling each column top to bottom."""
        rows = rows or grid_rows(len(movies), layout)
        cols = max(1, math.ceil(len(movies) / rows))
        cells = list(movies) + [None] * (rows * cols - len(movies))
        return cls(rows, cols, cells, layout)

    def at(self, col, row):
        if 0 <= col < self.cols and 0 <= row < self.rows:
            return self.cells[col * self.rows + row]
        return None

    def cell_of(self, key):
        i = self.index.get(key)
        return None if i is None else (i // self.rows, i % self.rows)

    def movies(self):
        return [m for m in self.cells if m is not None]

    def arranged_around(self, anchor_cell, ranked, blocked=(), blocked_penalty=2.5):
        """New wall with the anchor kept in place and `ranked` movies filling the nearest cells.

        Distance is measured in screen pixels so rows and columns weigh as they look. Cells in
        `blocked` (e.g. under the info panel) count as `blocked_penalty` cells farther away.
        """
        ac, ar = anchor_cell
        anchor = self.at(ac, ar)
        blocked = set(blocked)
        px, py = self.layout.pitch_x, self.layout.pitch_y

        def dist(cell):
            c, r = cell
            d = math.hypot((c - ac) * px, (r - ar) * py)
            if cell in blocked:
                d += blocked_penalty * px
            # Angle as a deterministic tie-break, clockwise from straight up.
            ang = math.atan2(c - ac, -(r - ar)) % (2 * math.pi)
            return (round(d, 6), round(ang, 6), c, r)

        order = sorted(((c, r) for c in range(self.cols) for r in range(self.rows)
                        if (c, r) != anchor_cell), key=dist)
        cells = [None] * (self.rows * self.cols)
        cells[ac * self.rows + ar] = anchor
        for (c, r), m in zip(order, ranked):
            cells[c * self.rows + r] = m
        return Wall(self.rows, self.cols, cells, self.layout)


def cell_origin(col, row, layout=G.POSTER):
    """Top-left of a cell in wall pixels."""
    return col * layout.pitch_x, row * layout.pitch_y


def top_margin(layout):
    """Gap above the top row on screen: the gutter between rows, so nothing of the row above
    shows (a wider gap would show a strip of its covers). The focus frame fits in it."""
    return layout.pitch_y - layout.cover_h


def full_rows(layout):
    """Rows whose covers (and focus frame) are whole on screen below the top margin."""
    vh = G.view_size(layout)[1]
    room = vh - top_margin(layout) - layout.cover_h - layout.frame
    return max(1, int(room // layout.pitch_y) + 1)


def camera_target(wall, cell, current=None, pin_top=False, centre_row=False):
    """Camera (wall-pixel top-left of the screen) for the focused `cell`.

    Across, the cell is centred (clamped to the wall). Down, the wall scrolls by whole rows: a
    row always sits whole at the top of the screen, never cut. The camera keeps its row
    (`current`, the camera now) while the cell is on one of the whole rows; otherwise the cell's
    row is put in the middle of them. `centre_row` (KScapeX: a key press that changes row) puts
    the row in the middle in any case, so the wall scrolls one row per press with the frame on
    the middle row, as it follows the cell across. `pin_top` shows the wall from its first row
    (it opens so).
    A wall smaller than the screen is centred on that axis."""
    lay = wall.layout
    x, _ = cell_origin(*cell, layout=lay)
    col, row = cell
    vw, vh = G.view_size(lay)
    wall_w = wall.cols * lay.pitch_x - (lay.pitch_x - lay.cover_w)
    wall_h = wall.rows * lay.pitch_y - (lay.pitch_y - lay.cover_h)
    margin_x, margin_y = lay.pitch_x * 0.5, top_margin(lay)

    if wall_w + 2 * margin_x <= vw:
        cx = (wall_w - vw) / 2.0
    else:
        cx = max(-margin_x, min(wall_w - vw + margin_x, x + lay.cover_w / 2 - vw / 2))

    if wall_h + 2 * margin_y <= vh:
        cy = (wall_h - vh) / 2.0
    else:
        n = full_rows(lay)
        last_top = max(0, wall.rows - n)
        if pin_top:
            top = 0
        else:
            top = None
            if current is not None and not centre_row:
                top = int(round((current[1] + margin_y) / lay.pitch_y))
                if not top <= row <= top + n - 1:
                    top = None
            if top is None:
                top = row - (n - 1) // 2
        top = max(0, min(last_top, top))
        cy = top * lay.pitch_y - margin_y
    return round(cx), round(cy)


def camera_reveal(wall, cell, current):
    """The camera that shows `cell` whole (with its frame) moving the wall as little as possible:
    `current` itself when the cell is on screen already. Used by the mouse, whose pointer is on
    the cell: centring it would carry it away from under the pointer. Rows keep the wall's whole
    rows (camera_target) when the cell is cut off above or below."""
    lay = wall.layout
    x, y = cell_origin(*cell, layout=lay)
    vw, vh = G.view_size(lay)
    fx, fy = G.fx(lay), lay.frame
    full = camera_target(wall, cell, current)
    cx, cy = current
    wall_w = wall.cols * lay.pitch_x - (lay.pitch_x - lay.cover_w)
    if wall_w + lay.pitch_x <= vw:
        cx = full[0]                                  # the wall fits across: it is centred
    else:
        lo, hi = x - fx, x + lay.cover_w + fx - vw    # camera range that shows the cell whole
        gap = lay.pitch_x - lay.cover_w
        if cx > lo:
            cx = lo - gap
        elif cx < hi:
            cx = hi + gap
        cx = max(-lay.pitch_x * 0.5, min(wall_w - vw + lay.pitch_x * 0.5, cx))
    if y - fy < cy or y + lay.cover_h + fy > cy + vh:
        cy = full[1]
    return round(cx), round(cy)


def in_opening_view(wall, cell):
    """True if `cell` is whole on screen when the wall shows its first row."""
    return cell[1] < full_rows(wall.layout)


def cell_at(layout, camera, x, y):
    """The grid cell whose cover is under view point (x, y) when the camera is at `camera`
    (wall pixels), or None over a gutter."""
    wx, wy = x + camera[0], y + camera[1]
    col, row = int(wx // layout.pitch_x), int(wy // layout.pitch_y)
    if wx < 0 or wy < 0:
        return None
    if wx - col * layout.pitch_x > layout.cover_w or wy - row * layout.pitch_y > layout.cover_h:
        return None
    return col, row


def ease_out_cubic(p):
    """Matches Kodi's tween="cubic" easing="out"."""
    p = max(0.0, min(1.0, p))
    return 1 - (1 - p) ** 3


BACK_OVERSHOOT = 1.70158


def ease_out_back(p, s=BACK_OVERSHOOT):
    """Matches Kodi's tween="back" easing="out": overshoots slightly, then settles."""
    p = max(0.0, min(1.0, p)) - 1
    return p * p * ((s + 1) * p + s) + 1


def clip_outside(origin, target, rect, margin):
    """Where a cover travelling origin -> target should start/end if target is off-screen.

    Returns target unchanged if it lies within `rect` grown by `margin`; otherwise the point on
    the segment just beyond that grown rect, so far-away covers enter or leave from the
    nearest edge instead of crossing the whole wall.
    """
    x0, y0, x1, y1 = rect[0] - margin, rect[1] - margin, rect[2] + margin, rect[3] + margin
    tx, ty = target
    if x0 <= tx <= x1 and y0 <= ty <= y1:
        return target
    ox, oy = origin
    dx, dy = tx - ox, ty - oy
    t_exit = 1.0
    for d, o, lo, hi in ((dx, ox, x0, x1), (dy, oy, y0, y1)):
        if d > 0:
            t_exit = min(t_exit, (hi - o) / d)
        elif d < 0:
            t_exit = min(t_exit, (lo - o) / d)
    t_exit = max(0.0, t_exit)
    return ox + dx * t_exit, oy + dy * t_exit


def _segment_hits_rect(p0, p1, rect):
    """True if the segment p0 -> p1 passes through the open rectangle (x0, y0, x1, y1)."""
    x0, y0, x1, y1 = rect
    t0, t1 = 0.0, 1.0
    dx, dy = p1[0] - p0[0], p1[1] - p0[1]
    for d, o, lo, hi in ((dx, p0[0], x0, x1), (dy, p0[1], y0, y1)):
        if abs(d) < 1e-9:
            if not lo < o < hi:
                return False
            continue
        a, b = (lo - o) / d, (hi - o) / d
        if a > b:
            a, b = b, a
        t0, t1 = max(t0, a), min(t1, b)
        if t0 >= t1:
            return False
    return True


def detour(start, end, keep_out, size, margin):
    """Waypoints that steer a flying cover around `keep_out`; [] if the straight path is clear.

    `start` and `end` are the cover's top-left corners, `size` its (w, h), and `keep_out` the
    rectangle (x0, y0, x1, y1) it must not cross - the selected cover and its frame. The cover
    is swept as a point against the rectangle grown by its size. The route goes round one
    corner of that grown rectangle (plus `margin`), or along a whole side via two corners when
    the cover has to cross from one side to the other; the shortest clear route wins.
    """
    w, h = size
    grown = (keep_out[0] - w, keep_out[1] - h, keep_out[2], keep_out[3])
    if not _segment_hits_rect(start, end, grown):
        return []
    x0, y0, x1, y1 = grown[0] - margin, grown[1] - margin, grown[2] + margin, grown[3] + margin
    tl, tr, bl, br = (x0, y0), (x1, y0), (x0, y1), (x1, y1)
    routes = [[tl], [tr], [bl], [br], [tl, tr], [tr, tl], [bl, br], [br, bl],
              [tl, bl], [bl, tl], [tr, br], [br, tr]]
    best = None
    for route in routes:
        points = [start] + route + [end]
        legs = list(zip(points, points[1:]))
        clear = not any(_segment_hits_rect(a, b, grown) for a, b in legs)
        length = sum(math.hypot(b[0] - a[0], b[1] - a[1]) for a, b in legs)
        key = (not clear, length)
        if best is None or key < best[0]:
            best = (key, route)
    return best[1]


def wave_delay(cell, centre, layout, step_ms):
    """KScapeX New wall test: when a cover turns over in the shuffle's wave (newwall.py), in ms:
    its distance from `centre` on screen, in cover widths, times `step_ms` - so the wave spreads
    from the selected cover in rings, as round on screen as the covers are tall."""
    dx = (cell[0] - centre[0]) * layout.pitch_x
    dy = (cell[1] - centre[1]) * layout.pitch_y
    return int(round(math.hypot(dx, dy) / layout.pitch_x * step_ms))
