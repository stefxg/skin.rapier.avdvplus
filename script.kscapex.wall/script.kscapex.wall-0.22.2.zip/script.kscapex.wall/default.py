"""Entry point.

RunScript(script.kscapex.wall)                    movies, in the view last used (wall or list)
RunScript(script.kscapex.wall,<kind>)             kind: movies, music or tv; view last used
RunScript(script.kscapex.wall,<kind>,<view>)      view: covers, list, collections or favorites
RunScript(script.kscapex.wall,<kind>,collections) that library's Collections view
RunScript(script.kscapex.wall,<kind>,newwall)     KScapeX: that library's wall in New wall test's look
                                                 (movies, tv), this once
RunScript(script.kscapex.wall,music,nowplaying)   Now Playing
RunScript(script.kscapex.wall,busytimeout)        Kodi's loading screen lasted 10 s: close it, stop the attempt
RunScript(script.kscapex.wall,startup)            Kodi started on Home: sync the colour theme, open nothing
RunScript(script.kscapex.wall,switchskin)         choose another installed skin and switch to it
RunScript(script.kscapex.wall,colours,<part>)     part: main or highlight - pick a theme colour
RunScript(script.kscapex.wall,display,<setting>)  aspect, rows, voffset, hoffset, safe, preview:
                                                 Skin settings → Display & aspect ratio
RunScript(script.kscapex.wall,versions,preference) Skin settings → Movie versions: preferred version
RunScript(script.kscapex.wall,scene,mark)         playback controls: mark a scene's start, then end
RunScript(script.kscapex.wall,demo,<cmd>)         cmd: next, prev, exit (keep watching) or stop -
                                                 passed to the scene playback service

One view at a time: a second request while a view is on screen is ignored; a request made from
Home while views are still open underneath it closes them first (modal.py).
"""
import sys

from resources.lib import modal
from resources.lib.kinds import KINDS
from resources.lib.skins import choose_skin, switch_to

VIEWS = {'covers': 'wall', 'list': 'list', 'favorites': 'favorites', 'favourites': 'favorites',
         'collections': 'collections', 'newwall': 'newwall'}


def run_view(fn):
    """Run `fn` (which opens KScape windows) as the one open view."""
    if not modal.claim():
        return
    done = modal.watch()
    try:
        fn()
    finally:
        done.set()
        modal.release()


def open_view(kind, view=None):
    from resources.lib.window import open_wall
    if view == 'collections':
        from resources.lib.collectionwindow import show_collections
        return show_collections(kind)
    if view == 'favorites':
        return open_wall(kind, favourites=True)
    if view == 'newwall':
        return open_wall(kind, view='wall', style='new')
    return open_wall(kind, view=view)


def now_playing():
    from resources.lib.nowplaying import show_now_playing
    show_now_playing()


def main(args):
    from resources.lib import regional
    regional.from_kodi()            # KScapeX: language and regional formats (dates, clock, titles)
    if args[:2] == ['scene', 'mark']:
        from resources.lib import scenes
        scenes.mark()
        return
    if args[:1] == ['demo'] and len(args) > 1:
        from resources.lib.demoservice import request
        request(args[1])
        return
    if args[:1] == ['display']:
        from resources.lib import displayui
        displayui.run(args[1:])
        return
    if args[:1] == ['versions']:
        from resources.lib import versionsui
        versionsui.run(args[1:])
        return
    if args[:1] == ['colours']:
        from resources.lib import colours
        colours.choose(args[1] if len(args) > 1 else 'main')
        return
    if args == ['busytimeout']:          # Kodi's loading screen has been up for 10 s: give up
        import xbmc
        if xbmc.getCondVisibility('Window.IsActive(busydialog) | Window.IsActive(busydialognocancel)'):
            xbmc.executebuiltin('Dialog.Close(busydialog,true)')
            xbmc.executebuiltin('Dialog.Close(busydialognocancel,true)')
            if not xbmc.getCondVisibility('Player.HasVideo | Player.HasAudio'):
                xbmc.executebuiltin('PlayerControl(Stop)')
        return
    if args == ['startup']:              # Kodi started on Home: show the colour theme in Skin settings
        from resources.lib import colours
        colours.sync()
        return
    if args == ['switchskin']:
        chosen = choose_skin()
        if chosen:
            switch_to(chosen)
        return
    kind = KINDS.get(args[0] if args else 'movies', KINDS['movies'])
    view = args[1] if len(args) > 1 else None
    if view == 'nowplaying':
        run_view(now_playing)
        return
    view = VIEWS.get(view)
    run_view(lambda: open_view(kind, view))


if __name__ == '__main__':
    main(sys.argv[1:])
